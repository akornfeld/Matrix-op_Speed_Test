/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rt_speedtest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;
//import static rt_speedtest.Util.*;

/**
 *
 * @author Ari
 */
public class Matrix extends ArrayList<double[]> {
    //----------------------------------------------------------------------------
    // Constructors
    public Matrix() {
        super();
    }

    public Matrix(int nrows, int ncols, double initialValue) {
        this();
        for (int idx = 0; idx < nrows; idx++) {
            double[] aRow = new double[ncols];
            Arrays.fill(aRow, initialValue);  // should I initialize?
            add(aRow);
        }
        
    }
    
    public Matrix(double[] values) {
        this();
        add(values);
    }

    /**
     * Creates a deep copy of matrix. (same as akmatrix.copy(), which is
     * slightly more efficient since this just calls copy.);
     * <P>
     * Primarily needed for NamedArray (?)
     *
     * @param matrix
     */
    public Matrix(Matrix matrix) {
        this();
        this.addAll(matrix.copy());

    }

    /**
     * Create a new matrix from a 1D double[], reshaped according to getDims:
 <BR> new Matrix(c(1d,2,3,4)) -> [1, 2, 3, 4]
     * <BR> new Matrix(c(1d,2,3,4), 2) -> [1, 2;  3, 4]
     * <BR> new Matrix(c(1d,2,3,4,5,6), 2, 3) -> [1, 2;  3, 4; 5, 6] (There's never a need to specify columns, though
     * <BR> new Matrix(c(1d,2,3,4,5,6), -1, 3) [-> [1,2,3;  4,5,6] (any row size < 1 will do)
     * @param values
     * @param dims 
     */
    public Matrix(double[] values, int... dims) {
        this();

        int nrows=0, ncols=0;
        switch (dims.length) {
            case 0 :
                nrows = 1;
                ncols = values.length;
                break;
            case 1 :
                nrows = dims[0];
                ncols = values.length/nrows;
                break;
            case 2:
                nrows = dims[0];
                ncols = dims[1];
                if (nrows < 1 && ncols > 0) {
                    nrows = values.length/ncols;
                }
                // just for symmetry
                if (ncols < 1 && nrows > 0) {
                    ncols = values.length/nrows;
                }
                break;
            default:
                assert dims.length < 3 : "Matrix only supports 2D arrays";
        }
        if (values.length != (nrows * ncols) ) {
            throw new RuntimeException("values length, " + values.length + ", does not match dims! (" + nrows + ", " + ncols + ")");
        }
        // row-wise copy elements into this:
        for (int idx = 0; idx < values.length; idx += ncols) {
            this.add(Arrays.copyOfRange(values, idx, idx + ncols));
        }
    }

    // Java can't convert long[] to int[], so we do it...
    public Matrix(double[] values, long... dims) {
        this(values, Arrays.stream(dims).mapToInt(x->(int)x).toArray());
    }
    
    // NOTE: MORE CONSTRUCTORS IN THE I/O SECTION
    
    /**
     * Make a deep copy of the data.
     *
     * @return
     */
    public Matrix copy() {
        // do a deep copy:
        //AKmatrix v = (Matrix) super.copy();

        // this should work w/o calling super
        return this.stream().map(row -> row.clone()).collect(Collectors.toCollection(Matrix::new));
    }

    public Matrix copyFrom(Matrix m) {
        int ncols = this.getNcols();
        assert ncols == m.getNcols() : "Matrix widths do not agree";
        assert this.getNrows() == m.getNrows() : "Matrix rows do not agree";
        int mIdx = 0;
        for (double[] row : this) {
            System.arraycopy(m.get(mIdx++), 0, row, 0, ncols);
        }
        return this;
    }
    /**
     * return a new one-row matrix copied from data[]. 
     * <BR> Negative numbers to count from the end
     * <BR>lastX can be omitted to specify the rest of the array
     *     Note that -n means omit the last n elements.
     * @param data
     * @param first - first element, inclusive. -n means, "n from the end"
     * @param lastX - optional. last element, <b>exclusive</b>; or -n to specify n-minus last. If omitted, copy to end.
     *         Additional first(-last) pairs can be specified to concatenate several regions.
     * <P> ex. 
     * <PRE>
     * <CODE>
     *    Matrix m1 = Matrix.copyFrom( c(1.0,2,3,4,5,6), 0, 2, 4, 6); //-> [1,2, 5,6]
     *    // is the same as:
     *    Matrix m1 = Matrix.copyFrom( c(1.0,2,3,4,5,6), 0, 2, -2); //-> [1,2, 5,6]
     * </CODE>
     * </PRE>
     * @return 
     */
    public static Matrix copyFrom(double[] data, int first, int... lastX) {
        assert lastX.length < 2 : "copyFrom can have at most three arguments.";
        
        Matrix m = new Matrix();
        int last= data.length;
        // was lastX specified:
        if (lastX.length > 0) {
            last = lastX[0];
        }
        // is first meant to be from the end?
        if (first < 0) {
            first = data.length + first;
        }
        // is last meant to be from the end?
        if (last < 0) {
            last = data.length + last;
        }
        double[] subset = Arrays.copyOfRange(data, first, last);
        m.add(subset);
        return m;
    }
    //----------------------------------------------------------------------------
    // Indexing
    /**
     *  Retrieve a single value as a double 
     * (all other index methods defined here return Matrix objects).
     * @param row
     * @param col
     * @return 
     */
    public double get(int row, int col) {
        return this.get(row)[col];
    }
    
    /**
     * Return a new Matrix object instead of double[]. 
     * <P>Note that get(int row) (defined in the superclass) returns the internal array
     *   whereas this function copies each array.
     *
     * @param rows - one or more row numbers (or an array of row numbers)
     * @return
     * @see ArrayList#get(int)
     */
    public Matrix getRows(int... rows) {
        assert rows.length > 0 : "No rows specified!";

        Matrix result; // = new Matrix();
        result = Arrays.stream(rows)
                        .mapToObj(row -> get(row).clone())
                        .collect(Collectors.toCollection(Matrix::new));
        //for (int row : rows) {
        //    result.addRows(get(row));
        //}
        return result;
    }

    /**
     * Returns the columns as a new matrix
     *
     * @param cols  - one or more column index. (or an array)
     * @return
     */
    public Matrix getCols(int... cols) {
        assert cols.length > 0 : "No columns specified!";

        Matrix result; // = new Matrix();
        result = this.stream().map(rowVal -> getRowCols(rowVal, cols)).
                collect(Collectors.toCollection(Matrix::new));
        //for (int row : rows) {
        //    result.addRows(get(row));
        //}
        return result;
    }

    public Matrix getCols(Matrix cols) {
        assert cols.getNrows() == 1 : "getCols(Matrix) must be called with a 1-row matrix";
        assert this.getNcols() == cols.getNcols() : String.format("Index matrix has different width (%d) than this matrix (%d)", cols.getNcols(), this.getNcols());
        
        double[] colSpecD = cols.get(0);
        long ncol = Arrays.stream(colSpecD).filter(x -> x > 0).count();
        int[] colSpec = new int[ (int)ncol ];
        
        int idx = 0;
        for (int n = 0; n < colSpecD.length;  n++ ) {
            if (colSpecD[n] > 0) {
                colSpec[idx++] = n;
            }
        }
        return getCols(colSpec);
    }
    
    /**
     * Get a submatrix specified by arrays of rows and of cols
     *
     * @param rows
     * @param cols
     * @return
     */
    public Matrix getMat(int[] rows, int cols[]) {
        Matrix result = this.getRows(rows).stream().map(aRow -> getRowCols(aRow, cols)).collect(Collectors.toCollection(Matrix::new));
        return result;
    }

    /**
     * Set all specified cells to the specified value.
     * @param rows - int array of row indexes
     * @param cols - a boolean array nCols long.
     * @param value
     * @return - the matrix, modified.
     */
    public Matrix setAll(int[] rows, boolean cols[], double value) {
        for (int rowIdx : rows) {
            double[] aRow = get(rowIdx);
            int idx = 0;
            for (boolean flag : cols) {
                if (flag) aRow[idx] = value;
                idx++;
            }
        }
        return this;
    }
    
    /**
     * Set value of a single cell.
     * @param row
     * @param col
     * @param value
     * @return  - the matrix, modified.
     */
    public Matrix set(int row, int col, double value) {
        double[] aRow = get(row);
        aRow[col] = value;
        return this;
    }
    
    public Matrix set(int row, int[] cols, double[] values) {
        double[] aRow = get(row);
        int valIdx = 0;
        for (int col : cols ) {
            aRow[col] = values[valIdx++];
        }
        return this;
    }
    /**
     * Copy a contiguous submatrix, somewhat more efficiently than constructing
     * the array of indexes.
     *
     * @param row0 - start row
     * @param row1 - end row (exclusive)
     * @param col0 - start col
     * @param col1 - end col (exclusive)
     * @return
     */
    public Matrix getMatContig(int row0, int row1, int col0, int col1) {
        Matrix result = new Matrix();
        for (int row = row0; row < row1; row++) {
            result.add(Arrays.copyOfRange(get(row), col0, col1 + 1));
        }
        return result;
    }

    // get an arbitrary set of columns from a specific row getRowCols(row, c(1,2,3)) 
    private static double[] getRowCols(double[] rowVals, int[] cols) {
        double[] result = new double[cols.length];
        for (int idx = 0; idx < cols.length; idx++) {
            result[idx] = rowVals[cols[idx]];
        }
        return result;
    }

    //----------------------------------------------------------------------------
    //  add/merge matrices
    
    // can't make a public method private:
    //@Override
    //private boolean add(double[] row) {
    //    return super.add(row);
    //}
    
    /**
     * Add <i>row</I> (not a copy) to the matrix.
     * @param row
     * @return 
     */
    public boolean addRow(double[] row) {
        int ncols = this.getNcols();
        if (ncols == 0 || row.length == ncols) {
            return super.add(row);
        } else {
            throw new RuntimeException("Row length doesn't match!");
            //return false;
        }
    }

    /**
     * Append a copy of matrix M to self.
     * @param M - a second matrix of the same width
     * @return 
     */
    public boolean addRows(Matrix M) {
        int ncols = this.getNcols();
        assert ncols == 0 || M.getNcols() == ncols : "Matrix widths do not match!";

        this.addAll(M.copy());
        return true;  // that's what ArrayList does!
    }
    
    /**
     *  Return a <B>new</B> matrix formed by appending copies of the columns. Matrices must have the same # of rows.
     * @param M2
     * @return 
     */
    public Matrix colAppend(Matrix M2) {
        Matrix result;
        int nrows = getNrows();
        if (nrows == 0) {
            result = new Matrix();
            result.addRows(M2);
        } else {
            assert M2.getNrows() == nrows : "Matrix lengths do not match! (" + nrows + " vs. " + M2.getNrows() + ")";

            int ncols1 = getNcols();
            int ncols2 = M2.getNcols();
            int ncols = ncols1 + ncols2; // the new matrix
            result = new Matrix();
            for (int row = 0; row < nrows; row++) {
                double[] rowVals = new double[ncols];
                System.arraycopy(this.get(row), 0, rowVals, 0, ncols1);
                System.arraycopy(M2.get(row), 0, rowVals, ncols1, ncols2);
                result.add(rowVals);
            }
        }
        return result;
    }

        
    //--------------------------------------------------------------------------------
    //  UTILITIES
    public int length() {
        if (size() == 0) {
            return 0;
        } else {
            return size() * get(0).length;
        }
    }

    public int getNcols() {
        return (size() == 0 ? 0 : get(0).length);
    }
    
    public int getNrows() {
        return size();
    }

    public int[] getDims() {
        int[] result = {size(), (size() > 0 ? get(0).length : 0)};
        return result;
    }

    //---------------------------------------------------------------------------
    // Math ops
    /**
     * Defines a simple interface for binary operations on doubles. Can be
     * satisfied by (x,y)-> x+y !
     */
    public interface binaryOperator {

        // returns the value, modifying a
        double op(double a, double b);
    }

    public interface unaryOperator {

        // returns the value, modifying a
        double op(double a);
    }

    public Matrix colMeans() {
        // note this is  much more efficient than the commented-out code!
        //Matrix result = new Matrix( new double[ getNcols() ] );  //(this.get(0).clone() ) 
        double[] result = new double[ getNcols() ];
        int nrows = this.getNrows();
        int ncols = this.getNcols();
        for (int r=0; r < nrows; r++) { //double[] row : this ) {
            double[] row = get(r);
            for (int c=0; c < ncols; c++) {
                 result[c] += row[c]; // add the value to the column sum.
            }
            //result.plusEquals( this.getRows(r) ); // note this.getRows() returns a new Matrix
        }
        //result.divEquals(nrows);
        for (int c=0; c < ncols; c++) {
            result[c] /= nrows;
        }
        return new Matrix( result );
    }
    
    public Matrix rowMeans() {
        /* old way:
        Matrix result = new Matrix();
        for (double[] row : this ) {
            double rowResult = Arrays.stream(row).sum() / row.length;
            result.add(c(rowResult));
        }
        return result;
        /* intermediate: (using stream)  not much better
        //Matrix result = new Matrix(getNrows(), 1, 0);
        double[] result = new double[ getNrows() ];
        int r = 0;
        for (double[] row : this ) {
            double rowResult = Arrays.stream(row).sum() / row.length;
            //result.get(r)[0] = rowResult;
            result[r] = rowResult;
            r++;
        }
        return  new Matrix( result );
        /* faster way: apparently streams are not all they're chalked up to be!! */
        double[] result = new double[ getNrows() ];
        int nrows = this.getNrows();
        int ncols = this.getNcols();
        for (int r=0; r < nrows; r++) { //double[] row : this ) {
            double[] row = get(r);
            for (int c=0; c < ncols; c++) {
                 result[r] += row[c]; // add the value to the row sum.
            }
            result[r] /= ncols;
        }

        //return new Matrix( result );
        return new Matrix( result, nrows, 1 );
        /**/
    }
    /**
     * Perform the requested operation on each element of this, m2, storing the
     * result in this. ex. selfOp( (x,y)-> x + y, M2) would addRows each element of M2 to this
     *
     * @param operator
     * @param m2
     * @return
     */
    public Matrix selfOp(binaryOperator operator, Matrix m2) {
        //  See math operator section, below
        assert this.getNrows() == m2.getNrows();
        assert this.getNcols() == m2.getNcols();

        for (int row = 0; row < size(); row++) {
            double[] thisRow = this.get(row);
            double[] m2Row = m2.get(row);

            for (int col = 0; col < thisRow.length; col++) {
                thisRow[col] = operator.op(thisRow[col], m2Row[col]);
            }
        }
        return this;
    }

    /**
     * Perform the requested operation on each element of this, and a scalar,
     * storing the result in this. ex. selfOp( (x,y)-> x + y, M2) would addRows each
 element of M2 to this
     *
     * @param operator
     * @param c
     * @return
     */
    public Matrix selfOpScalar(binaryOperator operator, double c) {
     //  See math operator section, below

        //AKmatrix result = new Matrix();
        for (int row = 0; row < size(); row++) {
            double[] thisRow = this.get(row);

            for (int col = 0; col < thisRow.length; col++) {
                thisRow[col] = operator.op(thisRow[col], c);
            }

        }
        return this;
    }

    public Matrix selfOp(unaryOperator operator) {
     //  See math operator section, below

        //AKmatrix result = new Matrix();
        for (int row = 0; row < size(); row++) {
            double[] thisRow = this.get(row);

            for (int col = 0; col < thisRow.length; col++) {
                thisRow[col] = operator.op(thisRow[col]);
            }

        }
        return this;
    }

    // Unfortunately, we need four variations for completeness
    public Matrix plus(Matrix m2) {
        return this.copy().plusEquals(m2);
    }

    public Matrix plus(double c) {
        return this.copy().plusEquals(c);
    }

    public Matrix plusEquals(Matrix m2) {
        return this.selfOp((x, y) -> x + y, m2);
    }

    public Matrix plusEquals(double c) {
        return this.selfOpScalar((x, y) -> x + y, c);
    }

    // minus
    public Matrix minus(Matrix m2) {
        return this.copy().minusEquals(m2);
    }

    public Matrix minus(double c) {
        return this.copy().minusEquals(c);
    }

    public Matrix minusEquals(Matrix m2) {
        return this.selfOp((x, y) -> x - y, m2);
    }

    public Matrix minusEquals(double c) {
        return this.selfOpScalar((x, y) -> x - y, c);
    }
    
    //
    public Matrix uminusEquals() {
        return this.selfOp((x) -> -x);
    }

    public Matrix power(double p) {
        return this.copy().selfOp(x -> Math.pow(x, p));
    }

    public Matrix powerEquals(double p) {
        return this.selfOp(x -> Math.pow(x, p));
    }

    // apply a polynomial to each element of the matrix
    //  coefs are in order 0, 1, 2, ... n
    public Matrix polyval(double... coefs) {
        assert coefs.length > 0 : "polyval needs at least one ceoefficient!";
        Matrix m = this.copy();

        return m.selfOp(x -> polyval(coefs, x));

    }
    

    // times
    public Matrix times(Matrix m2) {
        return this.copy().timesEquals(m2);
    }

    public Matrix times(double c) {
        return this.copy().timesEquals(c);
    }

    public Matrix timesEquals(Matrix m2) {
        return this.selfOp((x, y) -> x * y, m2);
    }

    public Matrix timesEquals(double c) {
        return this.selfOpScalar((x, y) -> x * y, c);
    }

    // divBy
    public Matrix divBy(Matrix m2) {
        return this.copy().divEquals(m2);
    }

    public Matrix divBy(double c) {
        return this.copy().divEquals(c);
    }

    public Matrix divEquals(Matrix m2) {
        return this.selfOp((x, y) -> x / y, m2);
    }

    public Matrix divEquals(double c) {
        return this.selfOpScalar((x, y) -> x / y, c);
    }

    /*
    

     public NamedArray  mtimes( B) {
     NamedArray val;
     val = NamedArray.binop(@mtimes, this, B);
     return val;
     }

     public NamedArray  rdivide( B) {
     NamedArray val;
     val = NamedArray.binop(@rdivide, this, B);
     return val;
     }

     public NamedArray  mrdivide( B) {
     NamedArray val;
     val = NamedArray.binop(@mrdivide, this, B);
     return val;
     }

     public NamedArray  mpower( B) {
     NamedArray val;
     val = NamedArray.binop(@mpower, this, B);
     return val;
     }

     // -----------------------------
     // redo summary functions to return a NamedArray if meaningful:  mean, sum ,etc [r.e. fn(x, dim)]
     //  we need varargout because some of the summary functions allow multiple outputs (see min, for example)
     public NamedArray  summary_op( sum_fun, varargin) {
     NamedArray varargout;
     [varargout[1:nargout]]  = sum_fun(double(this), varargin[:]);  // incredibly arcane MATALB syntax -- this only works if varargout is uninitialized, etc.

     if (varargout[1].getNcols() == this.colnames.length ) {
     // columns were preserved, we can preserve the object
     varargout[1] = NamedArray(varargout[1], this.colnames);
     } else  {
     // we've removed the colummns, just return a double
     }
     return varargout;
     }

     public NamedArray  sum( varargin) {
     NamedArray varargout;
     [varargout[1:nargout]] = summary_op(this, @sum, varargin[:]);  // note it should be sum@double but MATLAB complains at that and, conversely, doesn't ener an infinite loop this way
     return varargout;
     }

     public NamedArray  mean( varargin) {
     NamedArray varargout;
     [varargout[1:nargout]] = summary_op(this, @mean, varargin[:]);
     return varargout;
     }

     public NamedArray  median( varargin) {
     NamedArray varargout;
     [varargout[1:nargout]] = summary_op(this, @median, varargin[:]);
     return varargout;
     }

     public NamedArray  mad( varargin) {
     NamedArray varargout;
     [varargout[1:nargout]] = summary_op(this, @mad, varargin[:]);
     return varargout;
     }

     public NamedArray  max( varargin) {
     NamedArray varargout;
     [varargout[1:nargout]] = summary_op(this, @max, varargin[:]);
     return varargout;
     }

     public NamedArray  min( varargin) {
     NamedArray varargout;
     [varargout[1:nargout]] = summary_op(this, @min, varargin[:]);
     return varargout;
     }

     public NamedArray  mode( varargin) {
     NamedArray varargout;
     [varargout[1:nargout]] = summary_op(this, @mode, varargin[:]);
     return varargout;
     }

     public NamedArray  std( varargin) {
     NamedArray varargout;
     [varargout[1:nargout]] = summary_op(this, @std, varargin[:]);
     return varargout;
     }

     public NamedArray  var( varargin) {
     NamedArray varargout;
     [varargout[1:nargout]] = summary_op(this, @var, varargin[:]);
     return varargout;
     }

     // inherits these: ge, le, etc.

     public NamedArray  transpose() {
     NamedArray result;
     result = transpose(double(this)); // remove the class, since we don't store row names
     return result;
     }

     public NamedArray  ctranspose() {
     NamedArray result;
     result = ctranspose(double(this)); // remove the class, since we don't store row names
     return result;
     }
     */
    public int ismember(Matrix target) {
        return ismember(target, 0);
    }

    public int ismember(Matrix target, int startRow) {
         // start off simple: only check a single row matrix against a (multirow) target.
        // are members of A found in B?
        //  returns an a column vector representing whether each row of A is found in B
        //  simplest:  ismember(NamedArray([1, 2], {'a', 'b'}), NamedArray([1, 2; 3, 4], {'a', 'b'}) )
        //   reversed:  ismember(NamedArray([1, 2; 3, 4], {'a', 'b'}), NamedArray([1, 2], {'a', 'b'}) )

        // ultimately? we want to determine membership in B, for each row of A 
        //assert target instanceof NamedArray : "B must be a NamedArray object";
        if (this.isEmpty() || target.isEmpty()) {
            return -1;
        }
        // ELSE
        assert this.getNcols() == target.getNcols() : "Matrices must have the same number of columns";
        assert this.getNrows() == 1 : "Calling matrix must have a single row";
        // arrays are matched, convert to double for efficiency (and because B(1, 1) fails due to MATLAB odd subsref overloading rules)

        double[] testRow = this.get(0); // get the only row

        int row;
        for (row = startRow; row < target.size(); row++) {
            // compare row idx of A for equality of all elements within any row in B
            if (Arrays.equals(testRow, target.get(row))) {
                break;
            }
            //    result(idx) = any( arrayfun( @(idx2) isequal( this(idx, :), target(idx2, :) ), 1:target.getNrows ) );
        }

        return (row < target.size() ? row : -1);
    }

    private int k_runMean = 0;

    public Matrix addToRunningMean(Matrix m2) {
        // in-place running mean:  A[k] = A[k-1] + (m2 - A[k-1])/k
        if (this.isEmpty()) {
            // first element: initialize with the argument.
            this.addRows(m2.copy());
            k_runMean = 1;
        } else {
            assert this.getNrows() == m2.getNrows();
            assert this.getNcols() == m2.getNcols();
            if (k_runMean == 0) {
                // we are adding for the first time to a pre-loaded matrix, 
                //  initialize k_runMean on the fly
                k_runMean = 1;
            } //else if (k_runMean > 0) {
            //  throw new IllegalArgumentException("runningMean must be started with an empty matrix.");
            //}
            k_runMean++;

            this.plusEquals(m2.minus(this).divEquals((double) k_runMean));
        }
        return this;
    }

    @Override
    public String toString() {
        return this.stream()
                .map(x -> Arrays.stream(x)
                        .mapToObj(y -> String.format("%7.5g", y))
                        .collect(Collectors.joining(", ")))
                .collect(Collectors.joining(String.format("%n")));

    }
    
    /**
     *   Compute the polynomial c0 + c1*x + c2*x^2 + ... + cn*x^n
     * 
     * @param coefs - coefficients from 0 to nth-degree (opposite of MATLAB)
     * @param x
     * @return 
     */
    public static double polyval(double[] coefs, double x) {
        double y = coefs[0];
        double base = x;
        for (int i = 1; i < coefs.length; i++) {
            y += coefs[i] * x;
            x *= base; // raise x to the next power
        }
        return y;
    }

}
