/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rt_speedtest;

// Test the MATLAB trade-off between size and iterations, 

import java.util.Date;

//  using data structure and number of iterations found in RTMf.m.
//  The "small array" case is what it was in SCOPE v1.53 before my tinkering
//
//  All of the subfunctions here will perform the same number of operations
//  but the first one has 10x as many iterations in the for loop.
//  The remaining functions try different variations on increasing the data size and decreasing loops
// RESULTS (on my computer, MATLAB 2013b):
//   small array: 55.7s
//   10x cols   :  7.1s
//   10x rows   :  7.2s
//   10x rows*  :  7.3s (calculating row means instead of column means)
//   100x cols  :  2.0s
//   500x cols  :  0.8s ! (not in m file; just change 100 to 500, divide n_iter by 50 instead of 10)

/**
 * Java Result: (Java 8.0.20)
 *   Elapsed time (seconds): 12.518:  Small array, many iterations.
 *   Elapsed time (seconds): 6.41:  10x cols, 10x fewer iterations.
 *   Elapsed time (seconds): 11.572:  10x rows, 10x fewer iterations.
 *   Elapsed time (seconds): 22.928:  10x rows, 10x fewer iterations, row means.
 *   Elapsed time (seconds): 5.957:  100x cols, 100x fewer iterations.
 * 
 * @author Ari
 */
public class RT_SpeedTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    int nrows = 13;
    int ncols = 36;
    int n_iter = 626178; // 626178;  // 6,261,780 / 10  (another time SCOPE made 7,560,938 calls)
    int actual_iter;
    Matrix small_m = new Matrix(nrows, ncols, 0);  // or rand(13,36);
    Matrix m_10x_rows = new Matrix(nrows*10, ncols, 0);  // or rand(130,36);
    Matrix m_10x_cols = new Matrix(nrows, ncols*10, 0);  // or rand(13,360);
    Matrix m_100x_cols = new Matrix(nrows, ncols*100, 0);  // or rand(13,360);
    Matrix m_500x_cols = new Matrix(nrows, ncols*500, 0);  // or rand(13,360);

    // fill with random numbers:
    small_m.selfOp(RT_SpeedTest::random);
    m_10x_rows.selfOp(RT_SpeedTest::random);
    m_10x_cols.selfOp(RT_SpeedTest::random);
    m_100x_cols.selfOp(RT_SpeedTest::random);
    m_500x_cols.selfOp(RT_SpeedTest::random);
    
    //  tic toc is for convenience only
    // note the different function names differentiate them for the profiler ("Run and Time")
    // all three functions are identical
    tic();
    actual_iter = cols_array(small_m, n_iter*10);  // 10x iterations
    toc( String.format(":  Small array, %d iterations.", actual_iter));

    tic();
    actual_iter = cols_array(m_10x_cols, n_iter); // 10x columns
    toc( String.format(":  10x cols, 10x fewer iterations (%d).", actual_iter));

    tic();
    actual_iter = cols_array(m_10x_rows, n_iter);  // 10x rows
    toc( String.format(":  10x rows, 10x fewer iterations (%d).", actual_iter));

    tic();
    actual_iter = rows_array(m_10x_rows, n_iter);  // 10x rows
    toc( String.format(":  10x rows, 10x fewer iterations, row means (%d).", actual_iter));

    tic();
    actual_iter = cols_array(m_100x_cols, n_iter/10); // 100x columns, note that the base # of iterations is already max_iter/10 
    toc( String.format(":  100x cols, 100x fewer iterations (%d).", actual_iter));

    tic();
    actual_iter = cols_array(m_500x_cols, n_iter/50); // 500x columns, note that the base # of iterations is already max_iter/10 
    toc( String.format(":  500x cols, 500x fewer iterations (%d).", actual_iter));


    }

    public static double random(double ignore) {
        return Math.random();
    }
    public static int cols_array(Matrix my_m, int n_iter) {
        Matrix m1;
        int i;
        for (i =  0; i < n_iter ; i++ ) {
            m1 = my_m.colMeans();
            m1.set(0,0, 0d);  // just to make sure we're not optimizing it away (very unlikley)
        }
        // just a little junk code to use m
        //m1 = m1 + 1;
        return i;
    }
/*
    public static void cols_array(Matrix my_m, int n_iter) {
        Matrix m1;
        for (int i =  1; i <= n_iter ; i++ ) {
            m1 = my_m.colMeans();
        }
        // just a little junk code to use m
        //m1 = m1 + 1;
    }

    public static void cols_jumbo_array(Matrix my_m, int n_iter) {
        Matrix m1;
        for (int i =  1; i <= n_iter ; i++ ) {
            m1 = my_m.colMeans();
        }
        // just a little junk code to use m
        //m1 = m1 + 1;
    }

    public static void rows_array(Matrix my_m, int n_iter) {
        Matrix m1;
        for (int i =  1; i <= n_iter ; i++ ) {
            m1 = my_m.colMeans();
        }
        // just a little junk code to use m
        //m1 = m1 + 1;
    }
*/
    public static int rows_array(Matrix my_m, int n_iter) {
        Matrix m1;
        int i;
        for ( i =  0; i < n_iter ; i++ ) {
            m1 = my_m.rowMeans();
        }
        // just a little junk code to use m
        //m1 = m1 + 1;
        return i;
    }

    public static Date t1;
    public static Date t2;

    public static void tic() {
        t1 = new Date();
    }
    
    public static void toc(String comment) {
        long elapsedTime_ms; // ms elapsed time
        float elapsedTime_s;
        t2 = new Date();
        
        elapsedTime_ms = t2.getTime() - t1.getTime();
        elapsedTime_s = (float)elapsedTime_ms /(float)1000;
        System.out.println("  Elapsed time (seconds): " + elapsedTime_s + comment);

    }
}
